using System.Web.Mvc;

namespace Entity101.Data.Model.Controllers {

    public class TinyMCESampleController : Controller {

        //
        // GET: /TinyMCESample/

        public ActionResult Index() {

            return View();

        }

    }
}