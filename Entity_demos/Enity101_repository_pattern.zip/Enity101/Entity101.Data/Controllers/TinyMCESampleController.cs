using System.Web.Mvc;

namespace Entity101.Data.Controllers {

    public class TinyMCESampleController : Controller {

        //
        // GET: /TinyMCESample/

        public ActionResult Index() {

            return View();

        }

    }
}