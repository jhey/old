﻿using Enity101.Models;
using Entity101.Data;
using Entity101.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Enity101.Adapters.Data
{
    public class DataPostAdapter : IPostAdapter
    {
        public IndexViewModel GetAllPosts()
        {
            // get from db.....
            IndexViewModel vm = new IndexViewModel();
            vm.PageName = "FROM DATA Adapter Showing the posts";
            vm.Posts = new List<Post>();
            using (BlogDbContext db = new BlogDbContext())
            {
                vm.Posts = db.Posts.ToList();
            }
            return vm;
        }


        public void CreatePost(CreatePostViewModel model)
        {
            CreatePostViewModel vm = new CreatePostViewModel();
            // save to db
            Post temppost = new Post();
            temppost.Title = model.Title;
            temppost.Content = model.Body;
            temppost.BlogId = 1;
            using(BlogDbContext db = new BlogDbContext()){
                db.Posts.Add(temppost);
                db.SaveChanges();
            }
        }

        public UpdatePostViewModel ShowPost(int Id)
        {
            UpdatePostViewModel vm = new UpdatePostViewModel();
            vm.Msg = "DATA ADAPTER: Update the following post...";
            using (BlogDbContext db = new BlogDbContext())
            {
                vm.Post = db.Posts.Find(Id);
            }
            return vm;
        }

        public void UpdatePost(UpdatePostViewModel vm){
            using (BlogDbContext db = new BlogDbContext()) {
                Post tpost = new Post();
                tpost = db.Posts.Find(vm.Post.PostId);
                tpost.Title = vm.Post.Title;
                tpost.Content = vm.Post.Content;
                db.SaveChanges();
            }

        }

        public void DeletePost(int Id) {
            using (BlogDbContext db = new BlogDbContext()) {
                Post tpost = new Post();
                tpost = db.Posts.Find(Id);
                db.Posts.Remove(tpost);
                db.SaveChanges();
            }
        }



    }
}