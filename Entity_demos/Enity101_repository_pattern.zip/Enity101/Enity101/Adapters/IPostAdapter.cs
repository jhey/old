﻿using Enity101.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enity101.Adapters
{
    public interface IPostAdapter
    {
        // READ
        IndexViewModel GetAllPosts();
        // CREATE
        void CreatePost(CreatePostViewModel model);
        // UPDATE - Show
        UpdatePostViewModel ShowPost(int Id);
        // UPDATE - Execute
        void UpdatePost(UpdatePostViewModel vm);
        // DELETE
        void DeletePost(int Id);
    }
}
