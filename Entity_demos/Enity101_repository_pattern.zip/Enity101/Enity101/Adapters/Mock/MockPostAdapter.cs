﻿using Enity101.Models;
using Entity101.Data;
using Entity101.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Enity101.Adapters.Mock
{
    public class MockPostAdapter : IPostAdapter
    {

        public IndexViewModel GetAllPosts()
        {
            // get from mock.....
            IndexViewModel vm = new IndexViewModel();
            vm.PageName = "FROM MOCK Adapter Showing the posts";
            vm.Posts = new List<Post>();
            //
            vm.Posts.Add(new Post { PostId = 1, BlogId = 1, Content = "Lorum ipsum", Title = "First post" });
            vm.Posts.Add(new Post { PostId = 1, BlogId = 1, Content = "ipsol Lorum ipsum", Title = "Second post" });
            //
            return vm;
        }



        public void CreatePost(CreatePostViewModel model)
        {
            // Pending implementation..
        }

        public UpdatePostViewModel ShowPost(int Id)
        {
            // Pending implementation..
            return new UpdatePostViewModel();
        }


        public void UpdatePost(UpdatePostViewModel vm)
        {
            // Pending implementation..
        }

        public void DeletePost(int Id)
        {
            // Pending implementation..
        }


    }
}