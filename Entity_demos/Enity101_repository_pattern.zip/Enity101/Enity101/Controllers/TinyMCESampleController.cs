using System.Web.Mvc;

namespace Enity101.Controllers {

    public class TinyMCESampleController : Controller {

        //
        // GET: /TinyMCESample/

        public ActionResult Index() {

            return View();

        }

    }
}