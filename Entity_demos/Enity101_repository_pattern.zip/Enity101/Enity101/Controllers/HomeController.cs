﻿using Enity101.Models;
using Entity101.Data.Models;
using Entity101.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Migrations;
using Enity101.Adapters;
using Enity101.Adapters.Data;
using Enity101.Adapters.Mock;

namespace Enity101.Controllers
{
    public class HomeController : Controller
    {

        IPostAdapter _postAdapter;

        public HomeController()  {
            _postAdapter = new DataPostAdapter();
            //_postAdapter = new MockPostAdapter();

        }
        public HomeController(IPostAdapter ca) {
            _postAdapter = ca;
        }
 
        public ActionResult Index() {
            var vm = _postAdapter.GetAllPosts();
            return View(vm);
        }

        public ActionResult Create() { return View(); } // Show CRAETE page
        
        [HttpPost] // Process the CREATE page
        public ActionResult Create(CreatePostViewModel model) {
            _postAdapter.CreatePost(model);
            return RedirectToAction("Index");
        }
        // Show UPDATE page 
        public ActionResult Update(int Id) {
            var vm = _postAdapter.ShowPost(Id);
            return View(vm); 
        } 

        [HttpPost] // Process the UPDATE page
        public ActionResult Update(UpdatePostViewModel vm) {
            _postAdapter.UpdatePost(vm);
            return RedirectToAction("Index");
        }
        // Perform the Delete
        public ActionResult Delete(int Id) {
            _postAdapter.DeletePost(Id);
            return RedirectToAction("Index");
        }


    }
}