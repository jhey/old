tinyMCE.addI18n('en.example_dlg',{
	title : 'This is just a example title'
});
