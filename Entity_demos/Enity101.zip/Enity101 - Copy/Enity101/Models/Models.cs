﻿using Entity101.Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Enity101.Models
{
    // VM - Home page
    public class IndexViewModel {
        public string PageName {get; set;}
        public List<Post> Posts { get; set; }
    }
    // VM - CreatePost page
    public class CreatePostViewModel
    {
        [Required]
        public string Title { get; set; }
        public string Body { get; set; }
    }
    // VM - UpdatePost page
    public class UpdatePostViewModel
    {
        // Header page
        public string Msg { get; set; }
        // Post we are trying to  update
        public Post Post { get; set; }
    }



}