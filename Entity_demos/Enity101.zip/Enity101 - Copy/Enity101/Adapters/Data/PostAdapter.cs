﻿using Enity101.Models;
using Entity101.Data;
using Entity101.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Enity101.Adapters.Data
{
    public class PostAdapter : IPostAdapter
    {

        public IndexViewModel GetAllPosts()
        {
            IndexViewModel vm = new IndexViewModel();
            vm.PageName = "Showing the posts";
            vm.Posts = new List<Post>();
            using (BlogDbContext db = new BlogDbContext()){
                vm.Posts = db.Posts.ToList();
            }
            return vm;
        }


    }
}