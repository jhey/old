﻿using Entity101.Data.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity101.Data
{
    public class BlogDbContext : DbContext
    {
        public BlogDbContext() : base("DefaultConnection") { }

        public DbSet<Blog> Blogs { get; set; }
        public DbSet<Post> Posts { get; set; }

    }
}
