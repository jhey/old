﻿using Entity101.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.Migrations;

namespace Entity101.Data
{
    public static class Seeder {

        public static void Seed(BlogDbContext db) {

            db.Blogs.AddOrUpdate(b => new {b.Name },
                new Blog {
                    Name = "Dev Blog",
                    BlogId = 1
                });
        
            db.Posts.AddOrUpdate(p => p.Title,
                    new Post {
                        Title = "Hello blog world",
                        Content = "This is the body on my Post!",
                        BlogId = 1
                    },
                    new Post {
                        Title = "2nd Blog Post",
                        Content = "Lorum ipsum dolro....",
                        BlogId = 1
                    }
                );
            db.SaveChanges();


        }


    }
}
