﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity101.Data.Models
{
    public class Blog {
        // Id of the Blog
        public int BlogId { get; set; }
        // Name of the Blog 
        public string Name { get; set; }
        // List of all the Posts
        public virtual List<Post> Posts { get; set; }

    }
}
