﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity101.Data.Models
{
    public class Post
    {
        public int PostId { get; set; } // id of post
        public string Title { get; set; } // Post Title

        public string Content { get; set; } // Post body

        public int BlogId { get; set; } // Id of parent Blog
        public virtual Blog Blog { get; set; } // Blog class

    }
}
